#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
install.py — 把 commodity-supplier-sourcing 装到各家 AI 编程工具的默认位置

一个 skill 目录，多种平台的落点不同。这个脚本负责"复制到对的地方 + 写一行引用"，
重复执行不会产生重复内容（指针文件用标记块替换）。

用法：
  python scripts/install.py --list
  python scripts/install.py --platform claude
  python scripts/install.py --platform workbuddy
  python scripts/install.py --platform cursor  --project .
  python scripts/install.py --platform codex   --project .
  python scripts/install.py --platform gemini  --project .
  python scripts/install.py --platform custom  --path /some/dir

退出码：0 成功 / 1 参数错误 / 2 目标不可写
"""

import argparse
import os
import shutil
import sys

SKILL_NAME = "commodity-supplier-sourcing"
MARK_BEGIN = "<!-- BEGIN %s -->" % SKILL_NAME
MARK_END = "<!-- END %s -->" % SKILL_NAME

# 不复制到目标目录的东西：仓库自用文件，不是 skill 运行时需要的
SKIP_DIRS = {".git", ".github", ".cursor", ".vscode", ".idea",
             "dist", "tests", "docs", "examples", "output", "__pycache__"}
SKIP_FILES = {".gitignore", ".gitattributes", "README.md", "LICENSE",
              "CHANGELOG.md", "CONTRIBUTING.md", "AGENTS.md", "GEMINI.md"}

REPO_ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


def home(*parts):
    return os.path.join(os.path.expanduser("~"), *parts)


def copy_skill(dst):
    """把 skill 运行时文件复制到 dst（dst 就是 skill 目录本身）。"""
    os.makedirs(dst, exist_ok=True)
    n = 0
    for dp, dn, fn in os.walk(REPO_ROOT):
        dn[:] = [d for d in dn if d not in SKIP_DIRS]
        rel = os.path.relpath(dp, REPO_ROOT)
        target_dir = dst if rel == "." else os.path.join(dst, rel)
        os.makedirs(target_dir, exist_ok=True)
        for f in fn:
            if f in SKIP_FILES or f.endswith((".pyc", ".zip")):
                continue
            shutil.copy2(os.path.join(dp, f), os.path.join(target_dir, f))
            n += 1
    return n


def pointer_block(skill_dir, heading):
    """生成给 rule / context 文件用的引用块。路径统一用 /，跨平台可读。"""
    skill_dir = skill_dir.replace(os.sep, "/").rstrip("/")
    return "\n".join([
        MARK_BEGIN,
        "## %s" % heading,
        "",
        "本项目的「大宗商品供应商寻源」流程定义在此目录：`%s`" % skill_dir,
        "",
        "当用户要**找某个产品的国内生产厂家 / 要一份带电话和网站的厂家清单 / 采购前找货源**时：",
        "",
        "1. 先完整读 `%s/SKILL.md`，按里面的 S0–S7 七步执行；" % skill_dir,
        "2. 需要检索策略、产业带、验厂规则、输出规范时，再读 `references/` 下对应的文件；",
        "3. 产出用 `python %s/scripts/build_supplier_list.py suppliers.json --out ./out` 渲染；" % skill_dir,
        "4. **铁律：联系方式只能取自检索到的原文，查不到写「未公开」，绝不按区号规律拼号码。**",
        MARK_END,
        "",
    ])


def write_block(path, block):
    """把标记块写入 / 替换进文件（幂等）。"""
    old = ""
    if os.path.isfile(path):
        with open(path, "r", encoding="utf-8-sig") as f:
            old = f.read()
    if MARK_BEGIN in old and MARK_END in old:
        head = old.split(MARK_BEGIN)[0]
        tail = old.split(MARK_END, 1)[1].lstrip("\n")
        new = head + block + tail
    else:
        sep = "" if (not old or old.endswith("\n")) else "\n"
        new = old + sep + ("\n" if old else "") + block
    os.makedirs(os.path.dirname(os.path.abspath(path)) or ".", exist_ok=True)
    with open(path, "w", encoding="utf-8", newline="\n") as f:
        f.write(new)


PLATFORMS = {
    "claude":    ("Claude Code",      "~/.claude/skills/<name>/",            "skill"),
    "workbuddy": ("WorkBuddy",        "~/.workbuddy/skills/<name>/",         "skill"),
    "cursor":    ("Cursor",           ".cursor/skills/<name>/ + .cursor/rules/<name>.mdc", "rule"),
    "codex":     ("Codex / AGENTS.md","agents/skills/<name>/ + AGENTS.md",   "rule"),
    "gemini":    ("Gemini CLI",       ".gemini/skills/<name>/ + GEMINI.md",  "rule"),
    "custom":    ("自定义目录",        "--path 指定",                          "skill"),
}


def install(platform, project_dir, custom_path):
    if platform not in PLATFORMS:
        print("未知平台：%s（可选：%s）" % (platform, ", ".join(PLATFORMS)))
        return 1

    if platform in ("claude", "workbuddy"):
        base = home(".claude", "skills") if platform == "claude" else home(".workbuddy", "skills")
        dst = os.path.join(base, SKILL_NAME)
        n = copy_skill(dst)
        print("✅ %s：已复制 %d 个文件 → %s" % (PLATFORMS[platform][0], n, dst))
        print("   重启工具后，对它说「帮我找 XX 的国内生产厂家」即可触发。")
        return 0

    if platform == "custom":
        if not custom_path:
            print("--platform custom 需要同时给 --path")
            return 1
        dst = os.path.abspath(custom_path)
        n = copy_skill(dst)
        print("✅ 已复制 %d 个文件 → %s" % (n, dst))
        return 0

    project = os.path.abspath(project_dir or ".")

    if platform == "cursor":
        dst = os.path.join(project, ".cursor", "skills", SKILL_NAME)
        n = copy_skill(dst)
        rule = os.path.join(project, ".cursor", "rules", SKILL_NAME + ".mdc")
        body = ("---\n"
                "description: 大宗商品/工业品供应商寻源与联系方式清单\n"
                "alwaysApply: false\n"
                "---\n\n") + pointer_block(".cursor/skills/" + SKILL_NAME, "供应商寻源 Skill")
        write_block(rule, body)
        print("✅ Cursor：复制 %d 个文件 → %s" % (n, dst))
        print("   规则已写入：%s" % rule)
        return 0

    if platform == "codex":
        dst = os.path.join(project, "agents", "skills", SKILL_NAME)
        n = copy_skill(dst)
        write_block(os.path.join(project, "AGENTS.md"),
                    pointer_block("agents/skills/" + SKILL_NAME, "供应商寻源 Skill"))
        print("✅ Codex / AGENTS.md：复制 %d 个文件 → %s" % (n, dst))
        print("   引用块已写入：%s" % os.path.join(project, "AGENTS.md"))
        return 0

    if platform == "gemini":
        dst = os.path.join(project, ".gemini", "skills", SKILL_NAME)
        n = copy_skill(dst)
        write_block(os.path.join(project, "GEMINI.md"),
                    pointer_block(".gemini/skills/" + SKILL_NAME, "供应商寻源 Skill"))
        print("✅ Gemini CLI：复制 %d 个文件 → %s" % (n, dst))
        print("   引用块已写入：%s" % os.path.join(project, "GEMINI.md"))
        return 0

    return 1


def main():
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass

    ap = argparse.ArgumentParser(description="安装 commodity-supplier-sourcing 到各平台")
    ap.add_argument("--platform", help="claude / workbuddy / cursor / codex / gemini / custom")
    ap.add_argument("--project", default=".", help="项目目录（cursor/codex/gemini 用），默认当前目录")
    ap.add_argument("--path", default="", help="custom 平台的目标目录")
    ap.add_argument("--list", action="store_true", help="列出支持的平台与安装位置")
    args = ap.parse_args()

    if args.list or not args.platform:
        print("%-14s %-46s %s" % ("平台", "安装位置", "方式"))
        print("-" * 78)
        for k, (name, where, kind) in PLATFORMS.items():
            print("%-14s %-46s %s" % (k, where, "整目录复制" if kind == "skill" else "复制+写入引用"))
        print("\n例：python scripts/install.py --platform claude")
        return 0 if args.list else 1

    return install(args.platform, args.project, args.path)


if __name__ == "__main__":
    sys.exit(main())
