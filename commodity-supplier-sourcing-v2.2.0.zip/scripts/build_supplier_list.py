#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
build_supplier_list.py — 供应商清单构建与校验

把 suppliers.json 渲染成：
  1. 清单.html   可点击直拨 / 可复制 / 可筛选 / 手机自适应 / 零外链
  2. 清单.xlsx   冻结首行 + 筛选器 + 业务员跟进空列（无 openpyxl 时降级为 CSV）
  3. 校验报告.txt  号码格式、区号-省份一致性、同号多企、缺字段

用法：
  python build_supplier_list.py suppliers.json --out ./output
  python build_supplier_list.py suppliers.json --out ./output --title "碳化硅 厂家清单"
  python build_supplier_list.py suppliers.json --out ./output --name 碳化硅   # 输出 碳化硅-清单.html
  python build_supplier_list.py suppliers.json --check          # 只校验，不渲染
  python build_supplier_list.py suppliers.json --check-urls     # 额外检查官网可达性

设计原则：
  - 校验不通过**不阻塞渲染**，但在报告里显式列出（客户看到「待核实」比看到假数据安全）
  - 绝不修改、绝不补全任何号码，只报告问题
"""

import argparse
import csv
import hashlib
import json
import os
import re
import sys
import unicodedata

__version__ = "2.2.0"

# ---------- 常量 ----------

NA_VALUES = {"", "未公开", "-", "无", "无官网", "none", "null", "n/a", "na", "待核实"}

TIERS = ["龙头", "中坚", "区域专精"]
CONFS = ["A", "B", "C"]

PROV_ALIAS = [
    ("内蒙古", ["内蒙古自治区", "内蒙", "内蒙古"]),
    ("黑龙江", ["黑龙江省", "黑龙江"]),
    ("广西", ["广西壮族自治区", "广西"]),
    ("宁夏", ["宁夏回族自治区", "宁夏"]),
    ("新疆", ["新疆维吾尔自治区", "新疆"]),
    ("西藏", ["西藏自治区", "西藏"]),
    ("香港", ["香港特别行政区", "香港"]),
    ("澳门", ["澳门特别行政区", "澳门"]),
]

XLSX_HEADERS = [
    ("分层", 10), ("置信度", 9), ("匹配度", 8), ("公司名称", 34), ("省份", 10), ("城市", 10),
    ("产业集群", 14), ("主营产品与规格", 42), ("固话", 16), ("手机", 15), ("微信", 14),
    ("联系人", 16), ("邮箱", 26), ("官网", 30), ("最小起订量", 12), ("交期", 12),
    ("出口资质", 10), ("认证", 20), ("风险提示", 24), ("备注", 22), ("信息来源", 26),
    ("跟进状态", 12), ("负责人", 10), ("报价(元)", 12),
]

# 公司名里出现这些词、却标了 A 级，需要人工复核（贸易商常用）
TRADE_WORDS = ["贸易", "商贸", "供应链", "进出口", "物资", "经销", "销售", "批发", "机电设备", "工贸"]


# ---------- 工具 ----------

def clean(v):
    if v is None:
        return ""
    s = str(v).strip()
    return "" if s.lower() in NA_VALUES else s


def clean_contact(v):
    """联系方式专用：模板占位符（整段被中文/英文括号包住）视为空。"""
    s = clean(v)
    if s and s[0] in "（(" and s[-1] in "）)":
        return ""
    return s


def normalize_data(data):
    """把占位符形式的联系方式清洗成空字符串，再交给校验与渲染。"""
    for s in data.get("suppliers") or []:
        for k in ("landline", "mobile", "email", "website", "wechat"):
            if k in s:
                s[k] = clean_contact(s.get(k))
    return data


def norm_province(p):
    p = clean(p)
    if not p:
        return ""
    for canon, alias in PROV_ALIAS:
        if p in alias or any(a in p for a in alias):
            return canon
    for suf in ("省", "市", "特别行政区"):
        if p.endswith(suf):
            p = p[: -len(suf)]
    for suf in ("维吾尔", "壮族", "回族"):
        p = p.replace(suf, "")
    return p


def digits(s):
    return re.sub(r"\D", "", str(s or ""))


def split_ext(raw):
    """拆出主号与分机号。'0757-8888 转 8012' -> ('0757-8888', '8012')"""
    s = str(raw).strip()
    parts = re.split(r"转|分机|[Ee]xt\.?\s*[:：]?", s, maxsplit=1)
    main = parts[0]
    ext = digits(parts[1]) if len(parts) > 1 else ""
    return main, ext


def parse_phone(raw):
    """
    返回 dict(kind, digits, area_code, local_len, valid, reason)
    kind: landline / mobile / hotline / unknown
    """
    info = {"kind": "unknown", "digits": "", "area_code": "", "local_len": 0,
            "valid": False, "reason": ""}
    s = clean(raw)
    if not s:
        info["reason"] = "空"
        return info

    main, ext = split_ext(s)
    d = digits(main)
    info["digits"] = d

    # 去掉国际区号
    if d.startswith("0086"):
        d = d[4:]
    elif d.startswith("86") and len(d) > 11:
        d = d[2:]
    info["digits"] = d

    if not d:
        info["reason"] = "无数字"
        return info

    # 400 / 800 客服热线
    if d.startswith("400") or d.startswith("800"):
        info["kind"] = "hotline"
        info["valid"] = len(d) == 10
        info["reason"] = "" if info["valid"] else "客服热线应为 10 位"
        return info

    # 手机
    if d.startswith("1") and len(d) == 11:
        info["kind"] = "mobile"
        info["valid"] = bool(re.match(r"^1[3-9]\d{9}$", d))
        info["reason"] = "" if info["valid"] else "手机号第二位应在 3-9"
        return info

    # 固话
    if d.startswith("0"):
        if d[:2] in ("01", "02"):
            code, local = d[:3], d[3:]
        else:
            code, local = d[:4], d[4:]
        info["kind"] = "landline"
        info["area_code"] = code
        info["local_len"] = len(local)
        if len(local) in (7, 8):
            info["valid"] = True
        else:
            info["valid"] = False
            info["reason"] = "固话号码部分应 7-8 位，实际 %d 位" % len(local)
        return info

    # 没区号的 7-8 位座机
    if len(d) in (7, 8):
        info["kind"] = "landline"
        info["local_len"] = len(d)
        info["valid"] = False
        info["reason"] = "缺少区号"
        return info

    if d.startswith("1"):
        info["kind"] = "mobile"
        info["reason"] = "疑似手机号，应为 11 位（实际 %d 位）" % len(d)
        return info

    info["reason"] = "无法识别的号码格式（%d 位）" % len(d)
    return info


def load_area_codes(path):
    """返回 (code -> set(provinces), code -> set(cities))"""
    by_code_p, by_code_c = {}, {}
    try:
        with open(path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except Exception as e:
        print("[warn] 区号表加载失败：%s" % e, file=sys.stderr)
        return by_code_p, by_code_c
    for prov, city, code in data.get("codes", []):
        by_code_p.setdefault(code, set()).add(norm_province(prov))
        by_code_c.setdefault(code, set()).add(city)
    return by_code_p, by_code_c


# ---------- 校验 ----------

def _bigrams(text):
    """中文二元组，用于「整词没命中但语义明显相关」的兜底匹配。"""
    s = re.sub(r"[^\u4e00-\u9fa5A-Za-z0-9]+", "", text or "")
    return set(s[i:i + 2] for i in range(len(s) - 1))


# 这些二元组太泛，命中它们不能说明对方做的是本品类，需排除
BIGRAM_STOP = {
    "方案", "产品", "设备", "系统", "服务", "系列", "智能", "电子",
    "材料", "加工", "制造", "供应", "生产", "技术", "解决", "平台",
}


def category_tokens(data):
    """把品类名拆成可用于匹配的 token：先按标点切，再去掉噪音词。

    例：「半导体车机芯片（智能座舱 SoC）」+ keywords
      → ["半导体车机芯片", "智能座舱", "SoC", "智能座舱SoC", ...]
    """
    cat = clean(data.get("category"))
    raw = [cat]
    raw += [clean(k) for k in (data.get("keywords") or []) if clean(k)]
    out = []
    for x in raw:
        for piece in re.split(r"[（）()\[\]【】、/／,，;；:：·|\s]+", x):
            piece = piece.strip()
            if len(piece) >= 2 and piece not in out:
                out.append(piece)
    # 长的排前面，报错提示时更有信息量
    out.sort(key=len, reverse=True)
    return out


def covers_category(mp, tokens):
    """判断 main_products 是否覆盖本品类。返回 (是否覆盖, 命中说明)。

    两级判断：
      1) 整词命中任一品类词 / 别名 —— 直接算覆盖；
      2) 否则比对二元组，命中任一非泛用二元组也算覆盖。
         这一级是为了兜住「只写车型/型号/俗称」的真实厂家，
         例如品类是「智能座舱SoC」而主营写「RK3588M 车规座舱」。
    """
    if not mp or not tokens:
        return True, ""
    for t in tokens:
        if t in mp:
            return True, t
    g_mp = _bigrams(mp)
    g_cat = _bigrams(" ".join(tokens))
    hit = (g_mp & g_cat) - BIGRAM_STOP
    if hit:
        return True, "、".join(sorted(hit)[:3])
    return False, ""


def validate(data, by_code_p, by_code_c):
    errors, warns, dups, tips = [], [], [], []
    sups = data.get("suppliers") or []
    no_match = []
    cat_tokens = category_tokens(data)

    if not clean(data.get("verified_date")):
        errors.append("缺少 verified_date（信息核验日）—— 这是必填项，客户需要知道数据新鲜度")
    if not sups:
        errors.append("suppliers 为空")

    # 必填与取值
    for i, s in enumerate(sups, 1):
        nm = clean(s.get("name")) or "（第 %d 家未填名称）" % i
        for f in ("name", "province", "main_products", "confidence", "tier", "source"):
            if not clean(s.get(f)):
                errors.append("第 %d 家「%s」：缺少必填字段 %s" % (i, nm, f))
        c = clean(s.get("confidence")).upper()
        if c and c not in CONFS:
            errors.append("第 %d 家「%s」：confidence 只能是 A/B/C，当前为「%s」" % (i, nm, c))
        t = clean(s.get("tier"))
        if t and t not in TIERS:
            errors.append("第 %d 家「%s」：tier 只能是 龙头/中坚/区域专精，当前为「%s」" % (i, nm, t))
        if clean(s.get("main_products")):
            mp = clean(s.get("main_products"))
            if len(mp) < 4 or not re.search(r"\d|目|型|号|牌|级", mp):
                warns.append("第 %d 家「%s」：主营产品未写规格/牌号，客户无法判断是否匹配" % (i, nm))
        if not clean(s.get("landline")) and not clean(s.get("mobile")):
            warns.append("第 %d 家「%s」：无任何电话（仅有表单或未公开）" % (i, nm))
        if not clean(s.get("confidence_note")):
            tips.append("第 %d 家「%s」：未写置信度证据（建议一句话说明凭什么判 A/B/C）" % (i, nm))

        # 匹配度取值
        ms = s.get("match_score")
        if ms not in (None, ""):
            try:
                mv = int(ms)
                if mv < 1 or mv > 5:
                    errors.append("第 %d 家「%s」：match_score 应为 1–5，当前为 %s" % (i, nm, ms))
            except (TypeError, ValueError):
                errors.append("第 %d 家「%s」：match_score 必须是 1–5 的整数，当前为「%s」" % (i, nm, ms))
        else:
            no_match.append(nm)

        # 贸易商关键词 vs A 级 —— 最实用的一条矛盾预警
        nm_raw = clean(s.get("name"))
        hit = [w for w in TRADE_WORDS if w in nm_raw]
        if c == "A" and hit:
            warns.append("第 %d 家「%s」：公司名含「%s」却标 A 级 —— 确认是否自有生产，若只是销售主体应降为 B/C"
                         % (i, nm, "、".join(hit)))
        if c == "A" and not clean(s.get("confidence_note")):
            warns.append("第 %d 家「%s」：标 A 级但没写证据 —— A 级必须有环评/排污许可/经营范围含制造之一"
                         % (i, nm))

        # 邮箱格式
        em = clean(s.get("email"))
        if em and not re.match(r"^[^@\s]+@[^@\s]+\.[A-Za-z]{2,}$", em):
            warns.append("第 %d 家「%s」：邮箱「%s」格式不合法" % (i, nm, em))

        # 网址格式
        wb = clean(s.get("website"))
        if wb and not re.match(r"^(https?://)?[\w\-]+(\.[\w\-]+)+(/.*)?$", wb, re.I):
            warns.append("第 %d 家「%s」：网址「%s」格式异常" % (i, nm, wb))

        # 主营产品是否覆盖本品类（避免收录到跑偏的厂）
        # 品类名常常写成「半导体车机芯片（智能座舱 SoC）」这种带括注的长串，
        # 整串去匹配 main_products 几乎必然落空（实测 17/17 全是假阳性），
        # 所以拆成 token 逐个匹配：命中任意一个品类词 / 别名即视为覆盖。
        mp = clean(s.get("main_products"))
        if mp:
            ok, how = covers_category(mp, cat_tokens)
            if not ok:
                warns.append("第 %d 家「%s」：主营「%s」未出现品类词或别名（已试：%s）—— 确认是否做这个产品"
                             % (i, nm, mp[:28], "、".join(cat_tokens[:6])))

    # 号码格式 + 区号省份一致性
    for i, s in enumerate(sups, 1):
        nm = clean(s.get("name")) or "第 %d 家" % i
        prov = norm_province(s.get("province"))
        for field, label in (("landline", "固话"), ("mobile", "手机")):
            raw = clean(s.get(field))
            if not raw:
                continue
            info = parse_phone(raw)
            if not info["valid"]:
                warns.append("第 %d 家「%s」：%s「%s」格式异常 —— %s（已按待核实处理）"
                             % (i, nm, label, raw, info["reason"] or "未知原因"))
            if info["kind"] == "hotline":
                warns.append("第 %d 家「%s」：%s 是 400/800 客服热线，大宗采购建议再找固话或业务手机"
                             % (i, nm, raw))
            if info["kind"] == "landline" and info["area_code"] and prov:
                code = info["area_code"]
                if code in by_code_p:
                    allowed = by_code_p[code]
                    if prov not in allowed:
                        cities = "、".join(sorted(by_code_c.get(code, []))[:3])
                        errors.append(
                            "第 %d 家「%s」：固话区号 %s 属 %s（%s），但省份填的是「%s」—— 号码与地区不符"
                            % (i, nm, code, "/".join(sorted(allowed)), cities, prov))
                else:
                    warns.append("第 %d 家「%s」：区号 %s 不在内置区号表，请人工确认归属地"
                                 % (i, nm, code))

    # 同号多企
    phone_map = {}
    for s in sups:
        nm = clean(s.get("name"))
        for field in ("landline", "mobile"):
            d = parse_phone(s.get(field))["digits"]
            if len(d) >= 7:
                phone_map.setdefault(d, set()).add(nm)
    for d, names in phone_map.items():
        names = {n for n in names if n}
        if len(names) >= 3:
            errors.append("号码 %s 同时出现在 %d 家公司（%s）—— 疑似代账公司/招商平台，建议全部剔除或降 C"
                          % (d, len(names), "、".join(sorted(names)[:4])))
            dups.append((d, sorted(names)))
        elif len(names) == 2:
            warns.append("号码 %s 同时出现在 2 家公司（%s）—— 核实是否为集团总机"
                         % (d, "、".join(sorted(names))))
            dups.append((d, sorted(names)))

    # 公司名重复 / 近似
    seen = {}
    for s in sups:
        nm = clean(s.get("name"))
        key = re.sub(r"[\s（）()·．.、,，]", "", nm)
        key = re.sub(r"(股份有限公司|有限责任公司|有限公司|集团|公司)$", "", key)
        if key in seen and nm != seen[key]:
            warns.append("公司名疑似重复：「%s」与「%s」" % (seen[key], nm))
        seen.setdefault(key, nm)

    if no_match:
        tips.append("%d 家未填 match_score（匹配度 1–5），清单无法按「能不能做我这个件」排序：%s"
                    % (len(no_match), "、".join(no_match[:5]) + ("等" if len(no_match) > 5 else "")))

    # 品类整体健康度
    tiers_used = {clean(s.get("tier")) for s in sups}
    for t in TIERS:
        if t not in tiers_used:
            tips.append("没有任何一家被归入「%s」层 —— 三层不全是正常的，但请确认是否漏掉了该层代表企业" % t)

    return errors, warns, dups, tips


def check_urls(data):
    """可选：官网可达性检查（需联网）"""
    import urllib.request
    out = []
    for s in data.get("suppliers") or []:
        w = clean(s.get("website"))
        if not w:
            continue
        url = w if re.match(r"^https?://", w, re.I) else "http://" + w
        try:
            req = urllib.request.Request(url, method="HEAD",
                                         headers={"User-Agent": "Mozilla/5.0"})
            with urllib.request.urlopen(req, timeout=6) as r:
                out.append((clean(s.get("name")), w, r.status, ""))
        except Exception as e:
            out.append((clean(s.get("name")), w, 0, str(e)[:60]))
    return out


# ---------- 渲染 HTML ----------

def render_html(data, template_path, out_html, title):
    with open(template_path, "r", encoding="utf-8") as f:
        tpl = f.read()

    payload = json.dumps(data, ensure_ascii=False, indent=None, separators=(",", ":"))
    # 防止数据中出现 </script> 截断脚本
    payload = payload.replace("</", "<\\/")

    # 本地存储键：按「品类+核验日」区分，避免不同清单的跟进记录互相污染
    seed = "%s|%s|%s" % (clean(data.get("category")), clean(data.get("verified_date")), title)
    lskey = hashlib.md5(seed.encode("utf-8")).hexdigest()[:12]

    html = tpl.replace("__DATA_JSON__", payload)
    html = html.replace("__LSKEY__", lskey)
    html = html.replace("__TITLE__", title.replace("<", "&lt;"))
    # 构建标记：多个清单同时存在时，用来一眼区分「我看的是哪一次生成的」
    import datetime
    build_ts = datetime.datetime.now().strftime("%Y-%m-%d %H:%M")
    html = html.replace("__BUILD_TS__", build_ts)

    with open(out_html, "w", encoding="utf-8") as f:
        f.write(html)
    return out_html


# ---------- 渲染 Excel ----------

def sort_suppliers(sups):
    to = {t: i for i, t in enumerate(TIERS)}
    co = {c: i for i, c in enumerate(CONFS)}
    return sorted(sups, key=lambda s: (
        to.get(clean(s.get("tier")), 9),
        co.get(clean(s.get("confidence")).upper(), 9),
        norm_province(s.get("province")),
    ))


def render_xlsx(data, out_xlsx, title):
    sups = sort_suppliers(data.get("suppliers") or [])
    try:
        from openpyxl import Workbook
        from openpyxl.styles import Alignment, Border, Font, PatternFill, Side
        from openpyxl.utils import get_column_letter
    except ImportError:
        return render_csv(sups, out_xlsx.replace(".xlsx", ".csv"), title), "csv"

    wb = Workbook()
    ws = wb.active
    ws.title = re.sub(r"[\\/*?:\[\]]", "", clean(data.get("category")) or "厂家清单")[:31]

    ncol = len(XLSX_HEADERS)
    last_col = get_column_letter(ncol)

    # 标题行
    ws.merge_cells("A1:%s1" % last_col)
    c = ws["A1"]
    c.value = "%s（信息核验日：%s）" % (title, clean(data.get("verified_date")) or "未标注")
    c.font = Font(size=13, bold=True, color="111827")
    c.alignment = Alignment(vertical="center")
    ws.row_dimensions[1].height = 30

    # 表头
    thin = Side(style="thin", color="D1D5DB")
    border = Border(left=thin, right=thin, top=thin, bottom=thin)
    for j, (h, w) in enumerate(XLSX_HEADERS, 1):
        cell = ws.cell(row=2, column=j, value=h)
        cell.font = Font(bold=True, size=10, color="374151")
        cell.fill = PatternFill("solid", fgColor="F3F4F6")
        cell.alignment = Alignment(horizontal="center", vertical="center")
        cell.border = border
        ws.column_dimensions[get_column_letter(j)].width = w
    ws.row_dimensions[2].height = 26

    tier_fill = {"龙头": "EEF2FF", "中坚": "ECFEFF", "区域专精": "F8FAFC"}
    conf_font = {"A": "0F7B4F", "B": "A16207", "C": "6B7280"}

    for i, s in enumerate(sups, start=3):
        web = clean(s.get("website"))
        vals = [
            clean(s.get("tier")),
            clean(s.get("confidence")).upper(),
            s.get("match_score") or "",
            clean(s.get("name")),
            norm_province(s.get("province")),
            clean(s.get("city")),
            clean(s.get("cluster")),
            clean(s.get("main_products")),
            clean(s.get("landline")) or "未公开",
            clean(s.get("mobile")) or "未公开",
            clean(s.get("wechat")),
            clean(s.get("contact")),
            clean(s.get("email")) or "未公开",
            web or "无官网",
            clean(s.get("moq")),
            clean(s.get("lead_time")),
            clean(s.get("export_ready")),
            clean(s.get("certifications")),
            clean(s.get("risk")),
            clean(s.get("remark")),
            clean(s.get("source")),
            "", "", "",
        ]
        for j, v in enumerate(vals, 1):
            cell = ws.cell(row=i, column=j, value=v)
            cell.border = border
            cell.alignment = Alignment(vertical="top",
                                       wrap_text=j in (8, 18, 19, 20, 21),
                                       horizontal="center" if j in (1, 2, 3) else "left")
            cell.font = Font(size=10.5)
        ws.cell(row=i, column=1).fill = PatternFill("solid", fgColor=tier_fill.get(vals[0], "FFFFFF"))
        ws.cell(row=i, column=2).font = Font(size=10.5, bold=True, color=conf_font.get(vals[1], "000000"))
        ws.cell(row=i, column=4).font = Font(size=10.5, bold=True)
        # 官网超链接（第 14 列）
        if web:
            wc = ws.cell(row=i, column=14)
            wc.hyperlink = web if re.match(r"^https?://", web, re.I) else "http://" + web
            wc.font = Font(size=10.5, color="0E7490", underline="single")

    ws.freeze_panes = "A3"
    ws.auto_filter.ref = "A2:%s%d" % (last_col, max(2, len(sups) + 2))

    wb.save(out_xlsx)
    return out_xlsx, "xlsx"


def supplier_row(s):
    """按 XLSX_HEADERS 顺序输出一行（CSV 与 XLSX 共用）"""
    return [
        clean(s.get("tier")), clean(s.get("confidence")).upper(), s.get("match_score") or "",
        clean(s.get("name")), norm_province(s.get("province")), clean(s.get("city")),
        clean(s.get("cluster")), clean(s.get("main_products")),
        clean(s.get("landline")) or "未公开", clean(s.get("mobile")) or "未公开",
        clean(s.get("wechat")), clean(s.get("contact")),
        clean(s.get("email")) or "未公开", clean(s.get("website")) or "无官网",
        clean(s.get("moq")), clean(s.get("lead_time")), clean(s.get("export_ready")),
        clean(s.get("certifications")), clean(s.get("risk")),
        clean(s.get("remark")), clean(s.get("source")),
        "", "", "",
    ]


def render_csv(sups, out_csv, title):
    with open(out_csv, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f)
        w.writerow([h for h, _ in XLSX_HEADERS])
        for s in sups:
            w.writerow(supplier_row(s))
    return out_csv


# ---------- 报告 ----------

def write_report(path, data, errors, warns, dups, tips, url_results=None):
    sups = data.get("suppliers") or []
    cc = {c: sum(1 for s in sups if clean(s.get("confidence")).upper() == c) for c in CONFS}
    tc = {t: sum(1 for s in sups if clean(s.get("tier")) == t) for t in TIERS}

    L = []
    L.append("=== 校验报告 ===")
    L.append("标题：%s" % (clean(data.get("title")) or "-"))
    L.append("核验日：%s" % (clean(data.get("verified_date")) or "【缺失】"))
    L.append("总数：%d 家（%s）" % (len(sups), " / ".join("%s %d" % (t, tc[t]) for t in TIERS)))
    L.append("置信度：%s" % " / ".join("%s %d" % (c, cc[c]) for c in CONFS))

    ms = [int(s.get("match_score")) for s in sups
          if str(s.get("match_score") or "").strip().isdigit() and 1 <= int(s.get("match_score")) <= 5]
    if ms:
        L.append("匹配度：均分 %.1f（5 分 %d 家 / 4 分 %d 家 / ≤3 分 %d 家）"
                 % (sum(ms)/len(ms), ms.count(5), ms.count(4), sum(1 for x in ms if x <= 3)))
    can_tel = sum(1 for s in sups if clean(s.get("landline")) or clean(s.get("mobile")))
    can_we = sum(1 for s in sups if clean(s.get("wechat")))
    exporter = sum(1 for s in sups if clean(s.get("export_ready")) in ("是", "有", "可", "true", "True"))
    L.append("可联系性：可直接拨打 %d/%d，有微信 %d 家，可出口 %d 家"
             % (can_tel, len(sups), can_we, exporter))
    L.append("")

    def block(title, items, empty="无"):
        L.append("[%s]" % title)
        if items:
            for x in items:
                L.append("- " + x)
        else:
            L.append("- " + empty)
        L.append("")

    block("错误 必须修复", errors)
    block("警告 建议核实（已按待核实处理）", warns)
    block("提示", tips)

    if url_results:
        L.append("[官网可达性]")
        bad = [u for u in url_results if u[2] == 0]
        for nm, url, st, err in url_results:
            L.append("- %s %s → %s" % ("✗" if st == 0 else "✓", nm, url if st == 0 else str(st)))
        L.append("- 不可达 %d / %d（不可达不必删，可能是内网或防火墙）" % (len(bad), len(url_results)))
        L.append("")

    L.append("=== 结论 ===")
    if errors:
        L.append("存在 %d 条错误，交付前应修复（尤其是区号与省份不符、同号多企）。" % len(errors))
    else:
        L.append("无阻断性错误。")
    if warns:
        L.append("有 %d 条待核实项，已在清单中体现，交付时需向客户说明。" % len(warns))
    if not clean(data.get("verified_date")):
        L.append("⚠ 缺少核验日期，客户无法判断数据新鲜度。")

    text = "\n".join(L)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)
    return text


# ---------- main ----------

def main():
    ap = argparse.ArgumentParser(description="供应商清单构建与校验")
    ap.add_argument("json_file", nargs="?", help="suppliers.json 路径")
    ap.add_argument("--out", default="./output", help="输出目录，默认 ./output")
    ap.add_argument("--name", default="", help="输出文件前缀，如「车机芯片」→ 车机芯片-清单.html。"
                                              "同一目录要放多份清单时用它区分，默认不带前缀")
    ap.add_argument("--title", default="", help="清单标题，默认取 json 的 title")
    ap.add_argument("--template", default="", help="HTML 模板路径，默认 ../assets/list-template.html")
    ap.add_argument("--check", action="store_true", help="只校验，不渲染文件")
    ap.add_argument("--check-urls", action="store_true", help="额外检查官网可达性（需联网）")
    ap.add_argument("-V", "--version", action="version", version="%(prog)s " + __version__)
    args = ap.parse_args()

    for stream in (sys.stdout, sys.stderr):
        try:
            stream.reconfigure(encoding="utf-8")
        except Exception:
            pass

    if not args.json_file:
        ap.print_help()
        return 2

    if not os.path.isfile(args.json_file):
        print("找不到文件：%s" % args.json_file)
        return 2

    with open(args.json_file, "r", encoding="utf-8-sig") as f:
        data = json.load(f)

    data = normalize_data(data)

    title = args.title or clean(data.get("title")) or "供应商清单"

    here = os.path.dirname(os.path.abspath(__file__))
    area_path = os.path.join(here, "..", "references", "area-codes.json")
    by_code_p, by_code_c = load_area_codes(area_path)

    errors, warns, dups, tips = validate(data, by_code_p, by_code_c)
    url_results = check_urls(data) if args.check_urls else None

    # --out 本意是「输出目录」，但很容易被当成文件路径传进来
    # （例如 --out 清单.html），旧版会傻乎乎建一个名为「清单.html」的目录，
    # 文件全塞进 output/清单.html/ 里，事后极难发现。这里做兼容纠正。
    if os.path.splitext(args.out)[1].lower() in (".html", ".htm", ".xlsx", ".csv", ".txt"):
        d = os.path.dirname(os.path.abspath(args.out))
        print("[note] --out 收到的是文件路径「%s」，已按目录「%s」处理" % (args.out, d))
        args.out = d
    os.makedirs(args.out, exist_ok=True)

    # 输出文件名前缀：--name 优先，否则自动取品类名（去掉括注和文件系统非法字符）。
    # 都叫「清单.html」时，同目录放第二份会直接覆盖第一份，事后分不清看的是哪一版。
    prefix = clean(args.name)
    if not prefix:
        cat_raw = clean(data.get("category"))
        if cat_raw:
            prefix = re.split(r"[（(\[【/／,，·]", cat_raw)[0].strip()
            prefix = re.sub(r'[\\/:*?"<>|\s]+', "", prefix)[:14]
    out_name = (prefix + "-" if prefix else "") + "清单"

    if not prefix and os.path.isfile(os.path.join(args.out, "清单.html")):
        print("[warn] 输出目录里已有一份「清单.html」，本次将覆盖它。"
              "如果这是另一个品类的清单，请加 --name 区分，例如 --name 碳化硅")

    report_path = os.path.join(args.out, out_name + "-校验报告.txt")
    report = write_report(report_path, data, errors, warns, dups, tips, url_results)

    print(report)
    print("-" * 60)
    print("校验报告已写入：%s" % report_path)

    if args.check:
        return 1 if errors else 0

    # HTML
    tpl = args.template or os.path.join(here, "..", "assets", "list-template.html")
    if not os.path.isfile(tpl):
        print("[error] 找不到模板：%s" % tpl)
        return 2
    html_path = os.path.join(args.out, out_name + ".html")
    render_html(data, tpl, html_path, title)
    print("HTML 已生成：%s" % html_path)

    # Excel
    xlsx_path = os.path.join(args.out, out_name + ".xlsx")
    real, fmt = render_xlsx(data, xlsx_path, title)
    print("%s 已生成：%s" % (fmt.upper(), real))
    if fmt == "csv":
        print("[note] 未安装 openpyxl，已降级输出 CSV（Excel 可直接打开）。"
              "安装：pip install openpyxl")

    print("\n完成。共 %d 家厂家。" % len(data.get("suppliers") or []))
    return 1 if errors else 0


if __name__ == "__main__":
    sys.exit(main())
