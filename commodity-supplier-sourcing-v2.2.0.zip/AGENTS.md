# AGENTS.md

> 本文件供 Codex、Cursor、Zed、Jules 等读取 `AGENTS.md` 的智能体使用。
> 若你使用的是 Claude Code / WorkBuddy，直接读 [`SKILL.md`](SKILL.md) 即可。

## 这个仓库是什么

`commodity-supplier-sourcing` 是一个**供应商寻源 Skill**：把一个产品名，变成一份能直接打电话的国内主要生产厂家清单
（HTML 点击直拨 + Excel 跟进表 + 校验报告）。

它不是询价工具。询价、议价、靶心价请配合 `procurement-rfq` 使用。

## 什么时候用

用户说了这类话时触发：

- 「帮我找 XX 的国内生产厂家」「XX 都有哪些厂家」
- 「要一份带电话和网站的厂家清单」「查厂家联系方式」「厂家名录」
- 「采购前找货源」「出口采购寻源」「比价前先收集供应商」

## 怎么执行

1. **完整读 [`SKILL.md`](SKILL.md)**，按里面的 S0–S7 七步走，不要跳步。
2. 按需读 `references/` 下的专项文件：
   - `01-search-playbook.md` — 8 条检索渠道、检索式矩阵、平台陷阱
   - `02-industrial-belts.md` — 产业带地图（先产业带、后全国）
   - `03-vetting-rules.md` — 厂家 / 贸易商 / Fabless 的甄别证据链
   - `04-output-spec.md` — JSON schema 与字段字典
   - `area-codes.json` — 区号 → 省份映射，供脚本自动校验
3. 把结果写成 `suppliers.json`，然后渲染：

```bash
python scripts/build_supplier_list.py suppliers.json --out ./out
```

会产出 `<品类>-清单.html`、`<品类>-清单.xlsx`、`<品类>-清单-校验报告.txt`。

## 四条不可协商的约束

1. **联系方式只能来自检索到的原文。** 查不到写 `未公开`。**绝对禁止**按区号规律"拼"号码、按公司名猜邮箱、
   用模板套一个 `sales@公司名.com`。编一个号码，整份清单就废了，客户会照着打空号。
2. **必须区分厂家与贸易商。** 判不准就标 `B` 并在 `confidence_note` 里写清疑点，不要为了好看全标 `A`。
3. **必须分层。** 龙头 3–5 / 中坚 8–12 / 区域专精 5–8。25 家平铺等于没给建议。
4. **400 / 800 是客服热线，不是采购线。** 有固话或手机就优先给那个。

## 目录

```
SKILL.md              # 主流程（先读这个）
references/           # 检索、产业带、验厂、输出规范
assets/               # HTML 模板 + JSON 填写模板
scripts/
  build_supplier_list.py   # 校验 + 渲染
  install.py               # 装到各平台
examples/             # 真实案例（半导体车机芯片 17 家）
```

## 环境要求

- Python 3.8+，**仅用标准库**；`openpyxl` 可选（没有则 Excel 降级为 CSV）
- 需要联网检索

## 已知边界

- 目前只覆盖**中国大陆**厂商，海外供应商不适用。
- 产业带与区号表以中国大陆为主，港澳台及海外场景需自行补充。
- 清单只是"找到人"，不包含报价合理性判断。
