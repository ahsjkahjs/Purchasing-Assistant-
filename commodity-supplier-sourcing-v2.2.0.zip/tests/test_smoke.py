#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
冒烟测试：验证 build_supplier_list.py 的核心行为。
不依赖 pytest，直接 `python tests/test_smoke.py` 就能跑（CI 里也这么跑）。

覆盖：
  1. 正常数据能渲染出 HTML / XLSX(或 CSV) / 校验报告
  2. 模板占位符全部被替换（不留 __DATA_JSON__ / __BUILD_TS__ 这类残留）
  3. HTML 里确实有 N 行数据
  4. 假号码（区号与省份不符）会被判为错误，退出码非 0
  5. --name 能改变输出文件名
  6. install.py --list 能正常输出
"""

import json
import os
import subprocess
import sys
import tempfile

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
BUILD = os.path.join(ROOT, "scripts", "build_supplier_list.py")
INSTALL = os.path.join(ROOT, "scripts", "install.py")
EXAMPLE = os.path.join(ROOT, "examples", "suppliers_autosoc.json")

PY = sys.executable
fails = []


def run(args, **kw):
    return subprocess.run([PY] + args, capture_output=True, text=True,
                          encoding="utf-8", errors="replace", **kw)


def check(name, cond, detail=""):
    if cond:
        print("  ok   %s" % name)
    else:
        print("  FAIL %s %s" % (name, detail))
        fails.append(name)


def test_build_normal():
    print("\n[1] 正常渲染")
    if not os.path.isfile(EXAMPLE):
        check("examples 存在", False, EXAMPLE)
        return
    with tempfile.TemporaryDirectory() as td:
        r = run([BUILD, EXAMPLE, "--out", td])
        files = os.listdir(td)
        html = [f for f in files if f.endswith(".html")]
        sheet = [f for f in files if f.endswith((".xlsx", ".csv"))]
        report = [f for f in files if f.endswith(".txt")]
        check("退出码为 0（无阻断性错误）", r.returncode == 0, r.stdout[-400:])
        check("产出 HTML", len(html) == 1, str(files))
        check("产出表格", len(sheet) == 1, str(files))
        check("产出校验报告", len(report) == 1, str(files))

        if html:
            with open(os.path.join(td, html[0]), "r", encoding="utf-8") as f:
                doc = f.read()
            check("占位符已替换 __DATA_JSON__", "__DATA_JSON__" not in doc)
            check("占位符已替换 __BUILD_TS__", "__BUILD_TS__" not in doc)
            check("占位符已替换 __LSKEY__", "__LSKEY__" not in doc)
            check("构建标记存在", "本次生成于" in doc)

            with open(EXAMPLE, "r", encoding="utf-8") as f:
                n = len(json.load(f)["suppliers"])
            # 表格行是前端 JS 从内嵌 JSON 渲染的，静态 HTML 里只有一份行模板，
            # 所以这里数内嵌数据里的条目数，而不是数 <tr>。
            check("内嵌数据含 %d 家" % n, doc.count('"confidence_note":') == n,
                  "实际 %d" % doc.count('"confidence_note":'))
            check("行渲染模板存在", '<tr data-tier="' in doc)
            check("无外链依赖（零 CDN）",
                  "cdn." not in doc and "unpkg" not in doc and "jsdelivr" not in doc)


def test_bad_data():
    print("\n[2] 假数据必须被抓出来")
    bad = {
        "title": "测试 · 假数据",
        "category": "碳化硅",
        "keywords": ["碳化硅", "SiC"],
        "verified_date": "2026-10-21",
        "suppliers": [{
            "name": "示例耐火材料有限公司",
            "province": "山东",
            "city": "淄博",
            "main_products": "黑碳化硅 90 段砂，粒度 8-220 目",
            "confidence": "A",
            "tier": "中坚",
            "landline": "0757-88889999",
            "source": "测试",
        }],
    }
    with tempfile.TemporaryDirectory() as td:
        p = os.path.join(td, "bad.json")
        with open(p, "w", encoding="utf-8") as f:
            json.dump(bad, f, ensure_ascii=False)
        r = run([BUILD, p, "--check"])
        out = r.stdout + r.stderr
        check("区号 0757 配山东被判错", "区号" in out and "错误" in out, out[-300:])
        check("退出码非 0", r.returncode != 0, "returncode=%d" % r.returncode)


def test_name_prefix():
    print("\n[3] --name 控制输出名")
    with tempfile.TemporaryDirectory() as td:
        run([BUILD, EXAMPLE, "--out", td, "--name", "测试前缀"])
        files = os.listdir(td)
        check("文件名带自定义前缀",
              any(f.startswith("测试前缀-清单") and f.endswith(".html") for f in files),
              str(files))


def test_install_list():
    print("\n[4] install.py")
    r = run([INSTALL, "--list"])
    check("--list 正常输出", r.returncode == 0 and "claude" in r.stdout, r.stderr[-200:])


def main():
    for s in (sys.stdout, sys.stderr):
        try:
            s.reconfigure(encoding="utf-8")
        except Exception:
            pass

    print("=" * 56)
    print("commodity-supplier-sourcing 冒烟测试")
    print("=" * 56)
    test_build_normal()
    test_bad_data()
    test_name_prefix()
    test_install_list()

    print("\n" + "=" * 56)
    if fails:
        print("失败 %d 项：%s" % (len(fails), "、".join(fails)))
        return 1
    print("全部通过")
    return 0


if __name__ == "__main__":
    sys.exit(main())
