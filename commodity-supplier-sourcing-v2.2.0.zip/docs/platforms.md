# 各平台安装说明

本 skill 的形态是「一个目录 + 一份 SKILL.md」，各家工具的约定不同。`scripts/install.py` 负责放到对的位置，
并（在需要时）写一段路由说明。

先看支持列表：

```bash
python scripts/install.py --list
```

---

## Claude Code

```bash
python scripts/install.py --platform claude
```

复制到 `~/.claude/skills/commodity-supplier-sourcing/`。重启 Claude Code 后，
说「帮我找碳化硅的国内生产厂家」即可触发——Agent Skills 靠 `SKILL.md` 的 frontmatter `description` 匹配意图。

**只想给某个项目用？**

```bash
python scripts/install.py --platform custom --path .claude/skills/commodity-supplier-sourcing
```

## WorkBuddy

```bash
python scripts/install.py --platform workbuddy
```

复制到 `~/.workbuddy/skills/commodity-supplier-sourcing/`。这是用户级安装，所有项目共享。

## Cursor

```bash
cd <你的项目>
python <本仓库>/scripts/install.py --platform cursor --project .
```

会做两件事：

1. 把 skill 复制到 `.cursor/skills/commodity-supplier-sourcing/`
2. 写入 `.cursor/rules/commodity-supplier-sourcing.mdc`（`alwaysApply: false`，按需引用）

Cursor 的规则文件是路由层，真正的内容仍在 `SKILL.md` 与 `references/`，避免两处维护。

## Codex / 任意读 AGENTS.md 的工具

```bash
cd <你的项目>
python <本仓库>/scripts/install.py --platform codex --project .
```

- skill → `agents/skills/commodity-supplier-sourcing/`
- 在项目根 `AGENTS.md` 追加一段带标记的引用块（已存在则替换，不会重复）

`AGENTS.md` 是 [agents.md](https://agents.md) 约定的通用入口，Codex、Zed、Jules 等都能读。

## Gemini CLI

```bash
cd <你的项目>
python <本仓库>/scripts/install.py --platform gemini --project .
```

- skill → `.gemini/skills/commodity-supplier-sourcing/`
- 在 `GEMINI.md` 追加引用块

## 其他智能体 / 手动

```bash
python scripts/install.py --platform custom --path /path/to/somewhere
```

或者直接把整个目录拷过去，在系统提示里加一句：

> 需要找产品供应商时，先读 `<路径>/SKILL.md`，按其中的 S0–S7 流程执行。

---

## 平台能力差异

不是所有平台都等价。以本 skill 为例：

| 能力 | Claude Code / WorkBuddy | Cursor | Codex / AGENTS.md | 说明 |
|---|:---:|:---:|:---:|---|
| 按 `description` 自动触发 | ✅ | ⚠️ 靠规则语义 | ⚠️ 靠 AGENTS.md | 前两者是原生 skill 机制 |
| 读取 `references/` 分层材料 | ✅ | ✅ | ✅ | 都是普通文件读取 |
| 执行 `scripts/*.py` | ✅ | ✅ | ✅ | 需要本机有 Python |
| 跨会话保持 | ✅ | ✅ | ✅ | 规则/上下文文件本身就持久 |

**没有 Python 环境**也能用这个 skill——`SKILL.md` 里的流程是纯文档，
只是没法自动渲染 HTML/Excel，需要手动按 `04-output-spec.md` 的 schema 输出。

## 卸载

删掉对应目录即可：

```bash
rm -rf ~/.claude/skills/commodity-supplier-sourcing
rm -rf ~/.workbuddy/skills/commodity-supplier-sourcing
rm -rf .cursor/skills/commodity-supplier-sourcing .cursor/rules/commodity-supplier-sourcing.mdc
```

Codex / Gemini 方式额外需要手动删掉 `AGENTS.md` / `GEMINI.md` 里
`<!-- BEGIN commodity-supplier-sourcing -->` 与 `<!-- END ... -->` 之间的内容。
