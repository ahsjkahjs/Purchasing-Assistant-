# commodity-supplier-sourcing

**把一个产品名，变成一份能直接打电话的国内生产厂家清单。**

不是行业分析，不是名录堆砌——是一张排好优先级、号码能打通、点一下就能拨的电话作战台。

[![License: MIT](https://img.shields.io/badge/License-MIT-yellow.svg)](LICENSE)
![Python](https://img.shields.io/badge/python-3.8%2B-blue)
![Dependencies](https://img.shields.io/badge/dependencies-none-brightgreen)

![清单效果](docs/images/list-desktop.png)

---

## 它解决什么问题

采购最难的一步不是议价，是**找到人**。行业名录给你 200 家贸易商，B2B 平台给你一堆"实力商家"，
而你真正需要的是：这个产品国内谁在生产、在哪个产业带、采购负责人的电话是多少、我该先打哪 5 个。

这个 skill 就做这一件事，按重要性排三件事：

1. **号码是不是真的** — 编一个号码，整份清单就废了，客户还会照着打空号
2. **是不是真工厂** — 把贸易商当厂家谈，价格永远谈不到底
3. **有没有排优先级** — 25 家平铺等于没给建议

## 快速开始

```bash
git clone https://github.com/<your-name>/commodity-supplier-sourcing.git
cd commodity-supplier-sourcing
```

把 `assets/example-suppliers.json` 复制成 `suppliers.json` 填好，然后：

```bash
python scripts/build_supplier_list.py suppliers.json --out ./out
```

产出三个文件：

```
out/碳化硅-清单.html            可点击直拨、可筛选、可记录跟进、手机自适应
out/碳化硅-清单.xlsx            冻结首行 + 筛选器 + 跟进空列
out/碳化硅-清单-校验报告.txt     号码/区号/重复/缺字段的自动校验结果
```

只校验不出文件：

```bash
python scripts/build_supplier_list.py suppliers.json --check
```

## 安装到你的 AI 工具

```bash
python scripts/install.py --list          # 看支持哪些平台
python scripts/install.py --platform claude       # → ~/.claude/skills/
python scripts/install.py --platform workbuddy    # → ~/.workbuddy/skills/
python scripts/install.py --platform cursor  --project .   # → .cursor/skills/ + 规则
python scripts/install.py --platform codex   --project .   # → agents/skills/ + AGENTS.md
python scripts/install.py --platform gemini  --project .   # → .gemini/skills/ + GEMINI.md
```

| 平台 | 落点 | 触发方式 |
|---|---|---|
| Claude Code | `~/.claude/skills/<name>/` | 说「帮我找 XX 的国内生产厂家」 |
| WorkBuddy | `~/.workbuddy/skills/<name>/` | 同上 |
| Cursor | `.cursor/skills/` + `.cursor/rules/*.mdc` | 规则自动路由 |
| Codex / 任意读 `AGENTS.md` 的工具 | `agents/skills/` + `AGENTS.md` | 同上 |
| Gemini CLI | `.gemini/skills/` + `GEMINI.md` | 同上 |
| 任意智能体 | `--platform custom --path <dir>` | 手动引用 |

重复执行不会产生重复内容——引用块用标记块替换，幂等。
详细说明见 [`docs/platforms.md`](docs/platforms.md)。

## 反幻觉设计

这个工具的价值全押在"数据是真的"上，所以有四条不可协商的约束：

**① 联系方式只来自原文。** 查不到写 `未公开`。绝对禁止按区号规律拼号码、按公司名猜邮箱。
清单里出现最多的不是"某某公司"，而是老老实实的 `未公开`。

**② 区号 ↔ 省份自动交叉校验。** 内置约 200 个工业城市的区号表。`0757` 配「山东」立刻报错——
区号唯一对应城市，填错省份是最常见的假数据痕迹，机器能抓。

**③ 同号多企检测。** 同一个号码出现在 ≥3 家公司 → 代账公司或招商平台，直接判错。

**④ 厂家 / 贸易商 / Fabless 三套证据链。** 制造业看排污许可和车间，芯片设计公司看年报和料号——
用制造业的标尺量设计业，会把真厂家全判成贸易商。

校验不通过**不阻塞渲染**，但在报告里逐条列出。客户看到「待核实」比看到假数据安全。

## 输出长什么样

点开任意一行，右侧滑出详情：采购情报（起订量/交期/认证/出口资质）、为什么判 A 级、
风险提示、五种联系方式（可复制）、针对这一家的首联话术、通话记录。

![详情抽屉](docs/images/detail-drawer.png)

跟进状态、报价、备注存在浏览器本地，刷新不丢。填了两家以上报价，自动出现比价区。

手机上是卡片式，号码放大到能直接点：

<img src="docs/images/mobile.png" width="300">

## 目录结构

```
SKILL.md                       主流程：5 条铁律 + S0–S7 七步
AGENTS.md                      给 Codex / Cursor 等工具的路由说明
references/
  01-search-playbook.md        8 条检索渠道、检索式矩阵、平台陷阱
  02-industrial-belts.md       产业带地图（9 大类 ~150 品类）
  03-vetting-rules.md          验厂证据链（含 Fabless 例外）
  04-output-spec.md            JSON schema + 字段字典 + 渲染规范
  area-codes.json              约 200 个工业城市区号（机器可读）
assets/
  list-template.html           零外链 HTML 模板（内联 CSS/JS）
  example-suppliers.json       填写模板
scripts/
  build_supplier_list.py       校验 + 渲染（纯标准库）
  install.py                   多平台安装器
examples/
  suppliers_autosoc.json       真实案例：半导体车机芯片 17 家
tests/
  test_smoke.py                冒烟测试
```

## 真实案例

[`examples/suppliers_autosoc.json`](examples/suppliers_autosoc.json) 是一份完整跑通的数据：
半导体车机芯片（智能座舱 SoC），17 家厂商分三层，全部 A 级、17/17 可直拨。

这个案例专门挑了一个**和 skill 默认假设冲突**的品类来验证——芯片是 Fabless，没厂房、没排污许可、
注册在写字楼，而且买家根本买不到原厂货。跑完补了两处：

- `03-vetting-rules.md` 增加 A2b「品类例外」：用年报主营章节、官网料号与数据手册、
  整车厂量产定点公告，替代排污许可和环评
- 分层里单列 Tier1 / 方案商一层，因为原厂只对 OEM 和授权代理出货，直接打过去只会被转接

## 和 procurement-rfq 的分工

```
commodity-supplier-sourcing  →  找到人、能打通          （本仓库）
procurement-rfq              →  问到价、谈到靶心价
```

前者产出的是比价区的输入。两个 skill 边界清晰，不重叠。

## 已知边界

- 只覆盖**中国大陆**厂商；海外供应商不适用
- 产业带与区号表以大陆为主，港澳台场景需自行补充
- 清单解决"找到人"，不含报价合理性判断
- 网络检索有固有延迟，`verified_date` 超 12 个月建议重核

## English

A skill that turns a product name into a callable list of Chinese manufacturers:
search → verify factory vs. trader → extract verbatim contacts → validate area-code/province
consistency → render an interactive HTML phone sheet + Excel follow-up table.

Hard rule: **contact details must come from source text — never inferred.** Unknown → `未公开`.

Works with Claude Code, Cursor, Codex, Gemini CLI, or any agent that reads `AGENTS.md`.
Python 3.8+, standard library only.

## License

[MIT](LICENSE)
